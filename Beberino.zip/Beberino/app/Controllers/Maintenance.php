<?php

namespace App\Controllers;

class Maintenance extends BaseController
{
    public function index()
    {
        return view('maintenance'); // your views/maintenance.php
    }
}
