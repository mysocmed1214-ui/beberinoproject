<!-- Admin Login -->
<div class="d-flex align-items-center justify-content-center min-vh-100" style="background: #282828ff;">
  <div class="card shadow-lg p-4" style="max-width:400px; width:100%; background:#222; color:#f5f5f5; border-radius:12px;">
    <div class="text-center mb-4">
      <h3 style="color:#ff6f00;">Admin Login</h3>
    </div>

    <?php if (session()->getFlashdata('error')): ?>
      <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
    <?php endif; ?>

    <form action="<?= site_url('auth/adminLoginPost') ?>" method="post">
      <div class="mb-3">
        <label>Email</label>
        <input type="email" name="email" class="form-control" required
               style="background:#333; color:#f5f5f5; border:none;">
      </div>

      <div class="mb-3">
        <label>Password</label>
        <input type="password" name="password" class="form-control" required
               style="background:#333; color:#f5f5f5; border:none;">
      </div>

      <button type="submit" class="btn w-100" style="background:#ff6f00; color:#fff;">Login as Admin</button>
    </form>

    <div class="mt-3 text-center">
      <a href="<?= site_url('auth/admin_register') ?>" class="btn w-100" style="background:#444; color:#ff6f00; margin-top:10px;">Register as Admin</a>
    </div>

    <div class="mt-3 text-center">
      <a href="<?= site_url('auth/login') ?>" style="color:#bbb;">← Back to User Login</a>
    </div>
  </div>
</div>