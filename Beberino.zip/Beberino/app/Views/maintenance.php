<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Under Maintenance</title>
<style>
    body { background: #1e1e1e; color: #fff; font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; flex-direction: column; }
    h1 { font-size: 3rem; color: #ff8c00; }
</style>
</head>
<body>
<h1>⚠️ System Under Maintenance</h1>
<p>We'll be back online soon!</p>
</body>
</html>
